package logica;

import java.util.ArrayList;
import java.util.Date;

import persistencia.Archivo;

public class Restaurante {

	private ArrayList<TipoProducto> tipoProductos;
	private ArrayList<Producto> productos;
	private ArrayList<Combos> combos;
	private ArrayList<Factura> facturas;
	
	public Restaurante() {
		this.tipoProductos = new ArrayList<TipoProducto>();
		this.productos = new ArrayList<Producto>();
		this.combos = new ArrayList<Combos>();
	}

	public void ingresarTipoProducto(int id, String nombre) {
		TipoProducto tipoProducto = new TipoProducto(id, nombre);		
		this.tipoProductos.add(tipoProducto);
	}

	
	public void ingresarProducto(TipoProducto idTipoProducto, int codigo, String nombre, int precioVenta) {
		Producto productosT = new Producto(idTipoProducto, codigo, nombre, precioVenta);		
		this.productos.add(productosT);
	}
	
	public void ingresarCombos(int idCombos, Producto hamburguesa, Producto bebida, Producto acompanamiento) {
		Combos combos = new Combos(idCombos, hamburguesa, bebida, acompanamiento);		
		this.combos.add(combos);
	}
		

	public void imprimirProductos() {
		for(Producto producto : this.productos) {
				System.out.println("Tipo: " + producto.getTipoProducto().getNombre());
				System.out.println("Codigo Producto: " + producto.getCodigo());
				System.out.println("Nombre: " + producto.getNombre());
				System.out.println("Precio Venta: " + producto.getPrecioVenta());
				System.out.println("-----------");
		}
	}

	public void imprimirCombos() {
		for(Combos combos: this.combos) {
			Double precio = (combos.getHamburguesa().getPrecioVenta() + 
					combos.getBebida().getPrecioVenta() + 
					combos.getAcompanamiento().getPrecioVenta())*0.9;
				System.out.println("Codigo Producto: " + combos.getId());
				System.out.println("Hamburguesa: " + combos.getHamburguesa().getNombre());
				System.out.println("Bebida: " + combos.getBebida().getNombre());
				System.out.println("Acompañamiento: " + combos.getAcompanamiento().getNombre());
				System.out.println("Precio Venta: " + precio);
				System.out.println("-----------");
		}
	}
	
	public void leerArchivos() {
		ArrayList<String> lineas;
		lineas = Archivo.leerArchivo("Tipo de producto.dat");
		
		for(String linea : lineas) {
			String datos[] = linea.split(",");
			this.ingresarTipoProducto(Integer.parseInt(datos[0]), datos[1]);
		}
		
		lineas = Archivo.leerArchivo("Productos.dat");
		for(String linea : lineas) {
			String datos[] = linea.split(",");
			TipoProducto tipoProductoIngreso = buscarTipoProducto(Integer.parseInt(datos[0])); 
						
			this.ingresarProducto(tipoProductoIngreso, Integer.parseInt(datos[1]), datos[2], Integer.parseInt(datos[3]));
		}		
		
		lineas = Archivo.leerArchivo("Combos.dat");
		for(String linea : lineas) {
			String datos[] = linea.split(",");
			Producto hamburguesa = buscarProducto(Integer.parseInt(datos[1]));
			Producto bebida = buscarProducto(Integer.parseInt(datos[2]));
			Producto acompanamiento = buscarProducto(Integer.parseInt(datos[3]));
						
			this.ingresarCombos(Integer.parseInt(datos[0]), hamburguesa, bebida, acompanamiento);
		}
	}
	
	public TipoProducto buscarTipoProducto(Integer idTipoProducto) {
		for(TipoProducto tipoProducto: this.tipoProductos) {
			if(tipoProducto.getId() == idTipoProducto) {
				return tipoProducto;
			}
		}
		return null;
	}
	
	private Producto buscarProducto(Integer idProducto) {
		for(Producto producto : this.productos) {
			if(producto.getCodigo() == idProducto) {
				return producto;
			}
		}
		return null;
	}
	

	public void generarFactura(Date fecha, ArrayList<Integer> productosSeleccionados) {//[1,3,5]
		
		ArrayList<Producto> listaProdcutosComprados = new ArrayList<Producto>();
		for(Integer productos : productosSeleccionados) {
			Producto productoComprado = buscarProducto(productos);
			if(productoComprado != null) {
				listaProdcutosComprados.add(productoComprado);
			}
		}
		
		Integer total = 0;
		
		for(Producto listaProdcutod : listaProdcutosComprados) {
			total += listaProdcutod.getPrecioVenta();
		}
			System.out.print(total);
		
	}
	
	
	public void ingresarFactura(Date fecha, ArrayList<int[]> productosComprados) {
	
		int numero = this.facturas.size() + 1;
		Factura factura = new Factura(numero, fecha);
		for(int[] datos : productosComprados) {
			Producto producto = this.buscarProducto(datos[0]);
			factura.adicionarProducto(producto, datos[1]);
		}
		factura.calcularTotal();
		this.facturas.add(factura);
	}

//	private Producto buscarProducto(int idProducto) {
//		for(TipoProducto tipoProducto : this.tipoProductos) {
//			for(Producto producto : tipoProducto.getProductos()) {
//				if(producto.getCodigo() == idProducto) {
//					return producto;
//				}
//			}
//		}
//		return null;
//	}

/*
	public void imprimirFacturas() {
		for(Factura factura : this.hamburguesas) {
			System.out.println("-------");
			System.out.println(factura.getNumero() + "\n" + factura.getFecha() + "\n" + factura.getValorTotal() + "\n" + factura.getIva());
			for(FacturaProducto facturaProducto : factura.getFacturaProductos()) {
				System.out.println(facturaProducto.getProducto().getNombre() + "\n" + facturaProducto.getCantidad() + "\n" + facturaProducto.getPrecio());
			}
		}
		
	}*/
}
