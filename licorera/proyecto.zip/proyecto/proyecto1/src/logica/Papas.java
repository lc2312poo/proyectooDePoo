package logica;

public class Papas {
	private int id;
	private  String nombre;
	private char tamaño;
	private int precio;  	
 
}
