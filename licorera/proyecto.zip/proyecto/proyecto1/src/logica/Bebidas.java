package logica;

public class Bebidas {
	
	private int id;
	private String nombre;
	private char tamaño;
	private int precio;
}
